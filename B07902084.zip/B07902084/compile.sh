#!/bin/bash

# No need to compile, just execute the python file
